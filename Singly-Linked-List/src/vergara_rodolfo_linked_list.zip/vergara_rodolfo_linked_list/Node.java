package vergara_rodolfo_linked_list;

public class Node {
	public int Value;
	public Node next;

	public Node(int Value) {
		this.Value = Value;
		this.next = null;
	}
}
