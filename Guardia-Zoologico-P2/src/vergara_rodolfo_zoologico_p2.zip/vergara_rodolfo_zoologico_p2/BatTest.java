package vergara_rodolfo_zoologico_p2;

public class BatTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bat Wayne = new Bat();
		Wayne.attackTown();
		Wayne.attackTown();
		Wayne.attackTown();
		Wayne.eatHumans();
		Wayne.eatHumans();
		Wayne.fly();
		Wayne.fly();
	}

}
