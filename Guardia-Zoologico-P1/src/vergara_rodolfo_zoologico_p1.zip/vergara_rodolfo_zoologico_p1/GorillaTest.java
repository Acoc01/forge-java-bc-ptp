package vergara_rodolfo_zoologico_p1;

public class GorillaTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Gorilla DK = new Gorilla();
		DK.throwSomething();
		DK.eatBananas();
		DK.climb();
	}

}
