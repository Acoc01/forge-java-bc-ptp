package com.CodingDojo.Abraham;

public class Alumno {

}
