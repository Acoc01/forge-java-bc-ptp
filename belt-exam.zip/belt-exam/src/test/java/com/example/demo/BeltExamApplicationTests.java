package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
@SpringBootTest(classes=BeltExamApplicationTests.class)
class BeltExamApplicationTests {

	@Test
	void contextLoads() {
	}

}
